// This script defines the name of the IA instance that the website is connected to.
// This would only need changing if you've requested a new instance in order to support
// a custom demo or PoC engagement.
// Typically you will just need to replace 'iamdemo' with the name of your instance.


adserver = "http://crtl.aimatch.com/iamdemo/bserver";
settagserver = "http://crtl.aimatch.com/iamdemo";